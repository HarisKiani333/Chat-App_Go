CREATE TABLE "users"(
"id" bigserial PRIMARY KEY,
"username" varchar NOT NULL,
"email" varchar NOT NULL,
"password" varchar NOT NULL

)


CREATE TABLE "rooms"(
"id" bigserial PRIMARY KEY,
"name" varchar NOT NULL,
"userlist" TEXT NOT NULL,
"messages" TEXT NOT NULL

)